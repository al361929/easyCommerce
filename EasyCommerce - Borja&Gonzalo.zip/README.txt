En esta práctica hemos realizado la conexión con la base de datos, la cual se encuentra al final del fichero index.js.

Al final de este fichero también se encuentra la inserción de los datos obtenidos en kaggle a la bbbd.

Estos datos se encuentran en un fichero llamado data.csv.

Para hacer la inserción de los objetos hemos definido el schema y el método ad en el fichero ProductService.js.

Además de la inserción de objetos, también hemos realizado la inserción de comercios en el fichero CommerceService.js.